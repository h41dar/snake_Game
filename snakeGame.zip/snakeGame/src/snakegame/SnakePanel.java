/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package snakegame;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 *
 * @author h41dar21
 */
public class SnakePanel extends JPanel implements KeyListener , ActionListener {
    int  unit= 25 , bodyport= 0 , speed=100;
    int snakeX =0 , snakeY =0  , AppleX , AppleY;
    int chainX[]= new int[unit*unit];
    int chainY[]= new int[unit*unit];
    boolean right =false , left = false , up = false , down = false ; 
    Timer timer ;
    File  best_score;
    int scores[] = new int[5];
   
   
            

    Random rand = new Random();
    
    public SnakePanel() {
        
        
        best_score = new File("best_score.txt");
        
        try {
            best_score.createNewFile();
            //System.out.println(best_score.canRead());
            //System.out.println(best_score.canWrite());
            
        } catch (IOException ex) {
            Logger.getLogger(SnakePanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        try {
            Scanner sacn = new  Scanner(best_score);
            
            for (int i = 0; i < scores.length; i++) {
                scores[i]= sacn.nextInt() ;
                
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(SnakePanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        setBackground(Color.BLACK);
        addKeyListener(this);
        
        setFocusable(true);
        
        AppleX = unit * rand.nextInt(20);
        AppleY = unit * rand.nextInt(20);
        
        timer = new Timer(speed, this);
        timer.start();
        
        
        
        
        
    }
    
    

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); 
        
       
        
        g.setColor(Color.red);
        g.fillOval(snakeX, snakeY, unit, unit);
        
        
       for (int i = 0; i < bodyport; i++) {
       
        g.setColor(Color.PINK);
        g.fillOval(chainX[i], chainY[i], unit, unit);
            
        }
        
        g.setColor(Color.green);
        g.fillOval(AppleX, AppleY, unit, unit);
        
        g.setColor(Color.blue);
        g.drawString( bodyport+"", snakeX+5, snakeY+17);
     
//        g.setColor(Color.red);
//       for (int i = 0; i < getWidth(); i +=unit) {
//        g.drawLine(i, 0, i, getHeight());
//       g.drawLine(0, i, getWidth(), i);
//           
//       }
        
        
    }
    
    public void moveRight(){
       snakeX= snakeX +unit;
       repaint();
      
       
    }
    public void moveDown(){
       snakeY= snakeY +unit;
       repaint();
    }
    public void moveLeft(){
       snakeX= snakeX -unit;
       repaint();
       
    }
    public void moveUp(){
       snakeY= snakeY -unit;
       repaint();
       
    }
    public void randomApple(){
       AppleX = unit * rand.nextInt(20);
       AppleY = unit * rand.nextInt(20);
       repaint();
        
    }
    
    public void chainMove(){
       
        for (int i = bodyport; i > 0; i--) {
            chainX[i]= chainX[i-1];
            chainY[i]= chainY[i-1];
            
        }
        chainX[0]= snakeX;
        chainY[0]= snakeY;
    }
    
    public void grow(){
        
        if(snakeX == AppleX && snakeY == AppleY ){
           randomApple();
           bodyport++;
       } 
    }
     public void gameover(){
        
         
        for (int i = 0; i < bodyport; i++) {
            if(snakeX == chainX[i]  && snakeY == chainY[i] ){
                timer.stop();
                
            }
             
         }
         if(snakeX <0 || snakeY <0 || snakeX >= getWidth() || snakeY >=getHeight()){
          timer.stop();
          
       
         } 
         
         if(!timer.isRunning()){
             boolean match = true;
             for (int i = 0; i < scores.length; i++) {
                 if(scores[i]== bodyport ){
                     match = false;
                 }
             }
             
             
                 
             
             //System.out.println("i am working");
             for (int i = scores.length-1; i > 0; i--) {
                 //System.out.println(scores[i]<=bodyport);
                if(scores[i]<bodyport && match){
                   scores[4] =  bodyport;
                   break;
                }
             
                
            }
             
            int max ;
             for (int i = 0; i < scores.length; i++) {
                 max =i;
                 for (int j = 0; j < scores.length; j++) {
                     if(scores[max]>scores[j]){
                         int tmp = scores[max];
                         scores[max] =scores[j];
                         scores[j] =tmp;
                         
                         
                     }
                      
                 }
             }
             
             
            
             

             try {
            FileWriter Writer = new FileWriter(best_score);
            for (int i = 0; i < scores.length; i++) {
                 
                Writer.write(scores[i] + "\n");
                
                
            }
            
            
            Writer.close();
            
        } catch (IOException ex) {
            Logger.getLogger(SnakePanel.class.getName()).log(Level.SEVERE, null, ex);
        }
             
         }
         
         
         
        
         
         
    }
     
     public void reset(){
         right =false ; left = false ; up = false ; down = false ;  
         bodyport =0;snakeY =0;snakeX =0 ;
         
         
         timer.start();
         
         randomApple();
         repaint();
         
     }
    
    

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        //System.out.println(e.getKeyCode());
       
        
        
        if(e.getKeyCode()==KeyEvent.VK_UP){
            if(!down){
              right =false ; left = false ; up = true ; down = false ;  
            }
           
       }else if(e.getKeyCode()==KeyEvent.VK_DOWN){
           if(!up){
              right =false ; left = false ; up = false ; down = true ;  
            }
           
       }else if(e.getKeyCode()==KeyEvent.VK_LEFT){
           if(!right){
              right =false ; left = true ; up = false ; down = false ; 
            }
           
       }else if(e.getKeyCode()==KeyEvent.VK_RIGHT){
            if(!left){
              right =true ; left = false ; up = false ; down = false ; 
            }
       }
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void actionPerformed(ActionEvent e) {
         //gameover(); 
         grow();
         chainMove();
        if(timer.isRunning()){
            
           if(up){
               moveUp();
           }else if(down){
               moveDown();
           }else if(right){
               moveRight();
           }else if(left){
               moveLeft();
           } 
          
        }
        
        
    }

    
}
