/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package snakegame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.File;
import java.util.Scanner;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author h41dar21
 */
public class Gameover extends JPanel{
    JLabel gameover , score ;
    JLabel result[] = new JLabel[5];
    JPanel up , dawn;
    JButton restert;
    int best_score[] = new int[5];
    
    
    public Gameover() {
        setLayout(new GridLayout(2,1));
        //setBackground(Color.WHITE);
        
        
        fetch();
        
        up = new JPanel();
        up.setLayout(new GridLayout(6,0));
        up.setBackground(Color.BLACK);
        
        Font gameoverFont = new Font("Arial", Font.BOLD, 35);
        gameover = new JLabel("gameover"   ,   (int) CENTER_ALIGNMENT);
        gameover.setForeground(Color.RED);
        gameover.setFont(gameoverFont);
        
        score = new JLabel("last score : "   ,   (int) CENTER_ALIGNMENT);
        score.setForeground(Color.RED);
        Font scoreFont = new Font("Arial", Font.BOLD, 35);
        score.setFont(scoreFont);
        
        for (int i = 0; i < result.length; i++) {
             result[i] = new JLabel((1+i)+":"+ best_score[i], (int) CENTER_ALIGNMENT);
             result[i].setForeground(Color.RED);
            
        }
        
        dawn = new JPanel();
        dawn.setBackground(Color.BLACK);
        dawn.setLayout(new BorderLayout());
        add(up);
        add(dawn);
        
        up.add(gameover);
        
        for (JLabel result1 : result) {
            up.add(result1);
        }
        
         Font BtnFont = new Font("Arial", Font.BOLD, 30);
        restert = new JButton("restert");
        restert.setFont(BtnFont);


        restert.setForeground(Color.BLACK);
        restert.setOpaque(true);
        restert.setBorderPainted(false);
        restert.setBackground(Color.RED);
        restert.setBorder(BorderFactory.createEtchedBorder());
        
        dawn.add(restert ,BorderLayout.NORTH );
        dawn.add(score ,BorderLayout.CENTER );
         
        
    }
    
    public void fetch(){
        
        try{
            Scanner sacn = new  Scanner(new File("best_score.txt"));
        for (int i = 0; i < best_score.length; i++) {
            best_score[i] = sacn.nextInt();
            
        }
        sacn.close();
        }catch(Exception e){
            e.getMessage();
        }
        
        repaint();
        
    }
    
}
