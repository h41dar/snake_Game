/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package snakegame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;


/**
 *
 * @author h41dar21
 */
public class frameSnake extends JFrame implements ActionListener {
    SnakePanel snakePanel  ;
    Gameover gameoverPanel ;  
    

    public frameSnake() {
        setTitle("snake");
        setSize(500, 525);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        snakePanel  = new SnakePanel();
        gameoverPanel = new Gameover();  
        
        
        
   
        
        
        snakePanel.timer.addActionListener(this);
        gameoverPanel.restert.addActionListener(this);
        
        
        
        
        
        add(snakePanel);
        
       
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        snakePanel.setFocusable(true);

        
        snakePanel.gameover();
        
        
        
        
        
        
        if(!snakePanel.timer.isRunning()){
            
            remove(snakePanel);
            gameoverPanel.score.setText("your score :"+snakePanel.bodyport);
            
            for (int i = 0; i < 5; i++) {
                gameoverPanel.result[i].setText((i+1) +":"+ snakePanel.scores[i] );
            }
       
            add(gameoverPanel);
            
            revalidate();
            repaint();
            
            
        }
        
        
        
        if(e.getSource() == gameoverPanel.restert ){
            
               remove(gameoverPanel);
               snakePanel.reset();
                
               add(snakePanel);
               revalidate();
               repaint();
               snakePanel.requestFocus();
               
               
               
            
            }
    
    }

   

    
}
